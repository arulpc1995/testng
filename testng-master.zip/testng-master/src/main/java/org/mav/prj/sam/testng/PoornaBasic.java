package org.mav.prj.sam.testng;

public class PoornaBasic {
	public static void main(String[] args) {
		String i="poorna";
		System.out.println(i);
		
	}

}
