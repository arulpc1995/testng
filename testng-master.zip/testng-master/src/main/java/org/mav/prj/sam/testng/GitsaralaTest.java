package org.mav.prj.sam.testng;

public class GitsaralaTest {
public static void main(String[] args) {
	System.out.println("SaralaGit");
}
}
