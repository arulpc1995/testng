package org.mav.prj.sam.testng;

/**
 * Hello world!
 *
 */

public class App {
	public static void main(String[] args) {
		System.out.println("Hello World!");
	}

	private void arrySortbyBasavaiah() {
		System.out.println("Welcome");

	}
<<<<<<< HEAD
    private void testSarala() {
		System.out.println("Welcome");}



=======


    public static void arraySortbySwathi() {
		System.out.println("code by Swathi");
	}

	public static void add(int c, int d) {
		System.out.println(c + d);
	}

	public static void add(int a, int b, int c) {
		System.out.println(a + b + c);

	}
	
		public static void add(String a, int b) {
		System.out.println("added Basavaiah");
	}
>>>>>>> 6db4ae055ded72ec0555c589e463fb9aa8565074

}
