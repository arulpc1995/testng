package org.mav.prj.sam.testng;

public class IfanssDemo {
	public static void main(String[] args) {
		String i = "ifanss";
		System.out.println(i);
	}

}
