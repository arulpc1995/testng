package org.mav.prj.sam.testng;

public class Swathi {
public void name() {
	System.out.println("swathi");

}
	public static void main(String[] args) {
		Swathi swa=new Swathi();
		swa.name();

	}

}
