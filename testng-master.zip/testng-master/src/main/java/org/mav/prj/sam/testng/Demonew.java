package org.mav.prj.sam.testng;

public class Demonew {

	public void arulsort(int v,int w) {
		System.out.println(v+w);

	}
	
	
}
