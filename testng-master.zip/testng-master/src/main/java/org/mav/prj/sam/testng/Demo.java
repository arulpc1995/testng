package org.mav.prj.sam.testng;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("some code");
	}

}
