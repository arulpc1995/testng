package org.mav.prj.sam.testng;

public class BasavaiahClass {

}
