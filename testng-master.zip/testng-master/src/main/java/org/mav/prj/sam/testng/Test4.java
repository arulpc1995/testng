package org.mav.prj.sam.testng;

import org.junit.Test;

public class Test4 {

	@Test
	public static void testScript1() {
		System.out.println("this is my testscript1");
	}

}
