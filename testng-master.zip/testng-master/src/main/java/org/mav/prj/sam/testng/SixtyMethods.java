package org.maven.file.MavenFileHandling;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
//Base class
public class SixtyMethods {
	static WebDriver driver;

	public static WebDriver launch(String url) { //1
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Dhamodharan\\eclipse-workspace\\SeleniumLocators\\driver\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get(url);//16
		return driver;
	}
		public static String title( ) 
			{
			
			String url = driver.getTitle();//17
			return url;

			}
		public static String current()
			{
			String url = driver.getCurrentUrl();//18
			return url;
		}
	
	
	public static void type(WebElement e, String n) {//2
		e.sendKeys(n);
	}

	public static void clickBtn(WebElement e) {//3
		e.click();

	}

	public static void dropDown(WebElement e, int in) {//4
		Select s = new Select(e);
		s.selectByIndex(in);

	}
	public static void dropDown(WebElement e, String n) {//5
		Select s = new Select(e);
		s.selectByVisibleText(n); 

	}
	public static void dropDown(String n,WebElement e) {//6
		Select s = new Select(e);
		s.selectByValue(n);

	}
	public static void dropmulti(WebElement e,String n) {//7
		Select s = new Select(e);
		s.getOptions();

	}
	public static void dropmulti(String n,WebElement e) {//8
		Select s = new Select(e);
		s.getAllSelectedOptions();

	}
	public static void dropmultiple(String n,WebElement e) {//9
		Select s = new Select(e);
		s.getFirstSelectedOption();

	}
	public static void dropmultiple(WebElement e,String n) {//10
		Select s = new Select(e);
		s.isMultiple();

	}
	public static void deselectmulti(WebElement e,String n) {//11
		Select s = new Select(e);
		boolean multi = s.isMultiple();

	}
	public static void deselectmulti(String n,WebElement e) {//12
		Select s = new Select(e);
		s.deselectByValue(n);
	}
	public static void deselectmulti(int in,WebElement e) {//13
		Select s = new Select(e);
		s.deselectByIndex(in);
	}
	public static void deselectmultip(WebElement e,String n) {//14
		Select s = new Select(e);
		s.deselectByVisibleText(n);
	}

	public static void closeBrowser(WebDriver driver) {//15
		driver.quit();
	}
	public static void max( WebDriver driver) {//19
		
			driver.manage().window().maximize();
		}

	public static String getData(int row, int cell) throws Exception { //20
		File f = new File("C:\\Users\\Dhamodharan\\eclipse-workspace\\MavenFileHandling\\lib\\DataExcel.xlsx");
		FileInputStream s = new FileInputStream(f);
		Workbook w = new XSSFWorkbook(s);
		Sheet sheet = w.getSheet("datasarala");
		Row r = sheet.getRow(row);
		Cell c = r.getCell(cell);
		String value = null;
		int type = c.getCellType();
		if (type == 1) {
			value = c.getStringCellValue();
		} else if (type == 0) {
			if (DateUtil.isCellDateFormatted(c)) {
				Date d = c.getDateCellValue();
				SimpleDateFormat s1 = new SimpleDateFormat();
				value = s1.format(d);
			} else {
				double n = c.getNumericCellValue();
				long l = (long) n;
				value = String.valueOf(l);
			}
		}
		return value;
	}
	public static void robot() throws AWTException {//21
		Robot r1 = new Robot();
		r1.keyPress(KeyEvent.VK_CONTROL);
		r1.keyPress(KeyEvent.VK_A);
		r1.keyRelease(KeyEvent.VK_CONTROL); 
		r1.keyRelease(KeyEvent.VK_A);
}
	public static void rightclk(WebDriver driver) {//22

	Actions a =new Actions(driver);
	a.contextClick().perform();
}
	public static void dclick(WebElement e) {//30

		Actions a =new Actions(driver);
		a.doubleClick().perform();	}
	public static void select(WebElement e,String n ) //23
		{
		 boolean d1 = e.isSelected();
		
		}
		public static void enable(WebElement e) //24
			{
		boolean d2 = e.isEnabled();}
		public static void display(WebElement e) //25
		{
	boolean d3 = e.isDisplayed();}
			
			public static void refresh(WebDriver driver)//26
			{driver.navigate().refresh();
			}
			public static void back(WebDriver driver)//27
			{
			driver.navigate().back();
			}
			public static void forward(WebDriver driver)//28
			{
			driver.navigate().forward();
			}
public static void alert(WebDriver driver)//29
{
Alert a = driver.switchTo().alert();
a.accept();
}
public static void alertno(WebDriver driver)//31
{
Alert a = driver.switchTo().alert();
a.dismiss();
}
public static void iframe(WebElement e)//32
{
driver.switchTo().frame(e);
}
public static void iframe(String n)//33
{
driver.switchTo().frame(n);
}
public static void iframeid(String n)//34
{
driver.switchTo().frame(n);
}
public static void iframe(int in)//35
{
driver.switchTo().frame(in);
}
public static void alertprompt(WebDriver driver)//36
{
Alert a = driver.switchTo().alert();
a.sendKeys("yes");
a.accept();}
public static void alertpromptNo(WebDriver driver)//37
{
Alert a = driver.switchTo().alert();
a.sendKeys("no");
a.accept();
}
public static void Screen(WebDriver driver)//38
{
	TakesScreenshot t = (TakesScreenshot)driver;
}
public static void Scrollup(WebElement e) { //39
	JavascriptExecutor j = (JavascriptExecutor)driver;
	j.executeScript("argument[0].ScrollIntoView(true)", e);
}
public static void Scrolldwn(WebElement e) {//40
	JavascriptExecutor j = (JavascriptExecutor)driver;
	j.executeScript("argument[0].ScrollIntoView(false)", e);
}
public static void iframesize(WebDriver driver)//41
{
List<WebElement> f= (List<WebElement>) driver.findElement(By.tagName("iframes"));
int size =f.size();
System.out.println(size);
}
public static void wait(WebDriver driver) {//42
	driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
}
public static void thread(WebDriver driver) throws InterruptedException //43
{
Thread.sleep(5000);
}
public static void navigateTo(WebDriver driver,String url)//44
{driver.navigate().to(url);
}
public static void windows(WebDriver driver,String url)//45
{driver.switchTo().window(url);
}
public static void windows(String title, WebDriver driver)//46
{driver.switchTo().window(title);
}
public static void window(WebDriver driver,String windowsId)//47
{driver.switchTo().window(windowsId);
}
public static void window(WebDriver driver)//48
{driver.switchTo().defaultContent();
}
public static void drag(WebElement e,WebElement f)//49
{Actions a = new Actions(driver);
a.dragAndDrop(e, f).perform();
}
public static void keyDown(WebElement e)//50
{Actions a = new Actions(driver);
a.keyDown(e,Keys.SHIFT).perform();
}
public static void keyUp(WebElement e)//51
{Actions a = new Actions(driver);
a.keyUp(e,Keys.SHIFT).perform();
}
public static void waitclickable(WebDriver driver,WebElement e)//52
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.elementToBeClickable(e));
}
public static void waittitle(WebDriver driver,String n)//53
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.titleIs(n));
}
public static void waittitle(String n,WebDriver driver)//54
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.titleContains(n));
}
public static void waitalert(WebDriver driver)//55
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.alertIsPresent());
}
public static void waitelemt(WebDriver driver,WebElement e)//56
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.visibilityOfAllElements(e));
}
public static void waitelem(WebDriver driver,WebElement e)//57
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.visibilityOf(e));
}
public static void waitele(WebDriver driver,WebElement e)//58
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.invisibilityOf(e));
}
public static void waittext(WebDriver driver,WebElement e, String n)//59
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.textToBePresentInElement(e, n));
}
public static void waittextE(WebDriver driver,WebElement e, String n)//60
{WebDriverWait w = new WebDriverWait(driver,200);
w.until(ExpectedConditions.textToBePresentInElementValue(e, n));
}

}